export const CHOCOLATE = 'CHOCOLATE';
export const VANILLA = 'VANILLA';
export const STRAWBERRY = 'STRAWBERRY';
export const MOCHA = 'MOCHA';
export const PISTACHIO = 'PISTACHIO';
export const COOKIE_DOUGH = 'COOKIE_DOUGH';
export const COOKIES_AND_CREAM = 'COOKIES_AND_CREAM';
export const SALTED_CARAMEL = 'SALTED_CARAMEL';
