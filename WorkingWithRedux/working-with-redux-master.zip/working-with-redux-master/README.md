# O'reilly Working with Redux exercise files
These are the exercise files for O'reilly's React working with redux course.

## How they work
- Open the folder of the video in question (*The video is always the beginning state*)
- `$ npm install` or `$ yarn`
- `$ npm start` or `$ yarn start`