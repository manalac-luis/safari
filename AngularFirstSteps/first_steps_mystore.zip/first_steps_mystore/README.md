**Angular First Steps**

This directory contains instructions and slides of Yakov Fain's 3-hour "Angular First Steps" workshop where we build an app with Angular 6 and Bootstrap 4 with the hard-coded data on the client. 

If you're interested in Angular training or consulting, send an email at training@faratasystems.com.
