# AngularLiveLessons
This is the source code to accompany the "Learning Angular LiveLessons". It
covers Angular versions 2-5.  If you are looking for the source to accompany
"Learning AngularJS LiveLessons", please see the repo "LearningAngularJS".

If there are any bugs or problems with this source, please file a bug or--even
better--a pull request, and I'll get to it as soon as I can.

Thanks for watching!

