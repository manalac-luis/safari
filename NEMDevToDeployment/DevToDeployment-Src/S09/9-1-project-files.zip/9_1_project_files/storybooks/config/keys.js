module.exports = {
  mongoURI:'mongodb://CHANGEME',
  googleClientID:'CHANGEME',
  googleClientSecret:'CHANGEME'
}