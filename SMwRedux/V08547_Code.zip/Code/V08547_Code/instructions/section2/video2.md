```
store.dispatch({type: 'posts/NEW_POST', payload: {"hello": "World"}})
```

```
this.props.dispatch({type: 'posts/NEW_POST', payload: {"hello": "World"}})
```
