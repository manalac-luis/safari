```
import { connect } from 'react-redux'

```

```
export default connect(state => state.posts)(RedditPosts);
```
