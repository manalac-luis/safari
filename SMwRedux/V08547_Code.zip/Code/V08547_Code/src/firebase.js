import firebase from 'firebase'
var config = {
  apiKey: "AIzaSyCRp2wRtTMqaTY6YTuLRu3vrEuLdIunVWI",
  authDomain: "reddit-clone-d37b6.firebaseapp.com",
  databaseURL: "https://reddit-clone-d37b6.firebaseio.com",
  projectId: "reddit-clone-d37b6",
  storageBucket: "reddit-clone-d37b6.appspot.com",
  messagingSenderId: "243441491694"
};
firebase.initializeApp(config);
